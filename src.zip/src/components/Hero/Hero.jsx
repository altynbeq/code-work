import React from 'react';
import { Section, SectionText, SectionTitle } from '../../styles/GlobalComponents';
import Button from '../../styles/GlobalComponents/Button';
import { LeftSection } from './HeroStyles';
import { init } from "ityped";
import { useEffect, useRef } from "react";

export default function Intro() {
  const textRef = useRef();
  useEffect(() => {
    init(textRef.current, {
      showCursor: true,
      backDelay: 1500,
      backSpeed: 60,
      strings: ["Front-end developer", "UI Designer", "Content Creator"],
    });
  }, []);
  return (
    <Section row nopadding>
      <LeftSection>
        <SectionTitle main center>
          <h1>Hello, I am </h1>
          <h1>Altynbek Quat</h1>
        </SectionTitle>
        <SectionText>
        I'm a <span ref={textRef}></span>
        </SectionText>
        <Button onClick={href="https://www.linkedin.com/in/altynbek-quat-56b615194/"}>Contact</Button>
      </LeftSection>
    </Section>
  )
  }