export const projects = [{
        title: 'AMITTRADE',
    description: "Single handedly developed a website for a company operating within a food and automation industries. The web site contains information about the company and their product catalogue as well with the services they provide.",
        image: '/images/1.png',
        tags: ['HTML', 'Bootstrap', 'Javascript'],
        source: 'https://google.com',
        visit: 'https://google.com',
        id: 0,
    },
    {
        title: 'Portfolio',
        description: "Have developed a personal portfolio website, to tell more about myself for the recruitment processes and to demostrate the development skills. Source contains work history and accomplishments.",
        image: '/images/2.png',
        tags: ['React.js', 'JavaScript'],
        source: 'https://google.com',
        visit: 'https://google.com',
        id: 1,
    },
];

export const TimeLineData = [
    { year: 2019, text: 'Web Developer Intern at Visotskiy Consulting company. Almaty,Kazakhstan' },
    { year: 2019, text: 'Web Developer Intern at Smart Digital company. Almaty,Kazakhstan', },
    { year: 2019, text: 'Pursued bachelors degree on Computer Engineering at Vistula Universuty' },
    { year: 2020, text: 'Commercial experience developing web-site for the company.' },
];