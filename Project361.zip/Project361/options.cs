﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project361
{
    public partial class options : Form
    {
        public options()
        {
            InitializeComponent();
            // get the images to pictureboxes
            pictureBox1.Image = Image.FromFile(optionsCl.imageFolder + "diceregular\\Dice1static.png");
            pictureBox2.Image = Image.FromFile(optionsCl.imageFolder + "diceblue\\dice1.png");
            pictureBox3.Image = Image.FromFile(optionsCl.imageFolder + "dicephi\\dice1.png");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // get the flag, which indicates which dice design we need to use
            if (radioButton1.Checked == true)
            { optionsCl.diceType = 'R'; }
            else if (radioButton2.Checked == true)
            { optionsCl.diceType = 'B'; }
            else if (radioButton3.Checked == true)
            { optionsCl.diceType = 'M'; }

            this.Close();
        }
    }
}
