﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project361
{
    static public class optionsCl
    {
        public static char diceType = 'R';
        public static List<Player> players = new List<Player>();
        public static int goalPoint = 100;
        public static int numberOfPersons = 0;
        public static int numberOfBots = 0;
        public static int numberOfPlayers = 0;
        public static string imageFolder = "";
        public static int gameCounterInt = 0;
	}
}

