﻿using System;
using System.Windows.Forms;
using System.IO;

namespace Project361
{
    public partial class mainWindow : Form
    {
        public mainWindow()
        {
            InitializeComponent();

            // below we get the location of the dice images
            string workingDir = Environment.CurrentDirectory;
            string path = Directory.GetParent(workingDir).Parent.FullName;
            optionsCl.imageFolder = path + "\\img\\";
        }

        // open gameSettings window
        private void button1_Click(object sender, EventArgs e)
        {
            gameSettings gameSettings = new gameSettings();
            gameSettings.Show();
        }

        // open options window
        private void button4_Click(object sender, EventArgs e)
        {
            options options = new options();
            options.Show();
        }

        // quit button
        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("Do you want to quit?", "Quit?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            { Application.Exit(); }
        }

        // creators button
        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1. Diyorbek Tojikulov\t\t51542\n" +
                "2. Pavel Kurzo\t\t\t51673\n" +
                "3. Nurken Zhenisyly\t\t51573\n" +
                "4. Alisher Kairov\t\t\t51580\n" +
                "5. Altynbek Mukhametov\t\t51828\n", "Creators");
        }
    }
}
