﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project361
{
    public partial class playingField : Form
    {
        // these arrays store all controls generated on runtime
        List<Panel> listOfPanels;
        List<Label> listOfNames;
        List<Label> listOfPoints;
        List<PictureBox> listOfPictureBoxes;

        // timer stuff
        DateTime date;
        Timer timer;

        public playingField()
        {
            
            InitializeComponent();
            label2.Text = Convert.ToString(optionsCl.goalPoint);

            // set up players
            setUpNameLabels(optionsCl.players.Count);
            setUpPointLabels(optionsCl.players.Count);
            setUpPanels(optionsCl.players.Count);

            // get players information
            for (int i = 0; i < optionsCl.players.Count; i++)
            {
                listOfNames[i].Text = optionsCl.players[i].name;
                listOfPoints[i].Text = Convert.ToString(optionsCl.players[i].point);
                listOfPanels[i].BackColor = optionsCl.players[i].SetColor;
            }
        }

        #region Set up Player Names And Point Counters
        
        public void setUpPanels(int n)
        {
            listOfPanels = new List<Panel>();

            // set up player information panels based on the number of players
            int xValue = 0;
            switch (n)
            {
                case 2: xValue = 398; break;
                case 3: xValue = 262; break;
                case 4: xValue = 194; break;
                default:
                    break;
            }

            for (int i = 0; i < n; i++)
            {
                listOfPanels.Add(new Panel());

                listOfPanels[i].Controls.Add(listOfNames[i]);
                listOfPanels[i].Controls.Add(listOfPoints[i]);
                listOfPanels[i].Location = new System.Drawing.Point((i * xValue) + (i * 10)+10, 499);
                listOfPanels[i].Name = "panel" + (i + 1);
                listOfPanels[i].BackColor = Color.Transparent;
                listOfPanels[i].Size = new System.Drawing.Size(xValue-10, 48);
                Controls.Add(listOfPanels[i]);
            }
        }

        public void setUpNameLabels(int n)
        {
            listOfNames = new List<Label>();

            float tSize = 14.25F;
            switch (n)
            {
                case 2: tSize = 14.25F; break;
                case 3: tSize = 12.25F; break;
                case 4: tSize = 10.25F; break;
                default:
                    break;
            }

            for (int i = 0; i < n; i++)
            {
                listOfNames.Add(new Label());

                listOfNames[i].AutoSize = true;
                listOfNames[i].BackColor = System.Drawing.Color.Transparent;
                listOfNames[i].Font = new System.Drawing.Font("OCR A Extended", tSize, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                listOfNames[i].ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(178)))), ((int)(((byte)(138)))));
                listOfNames[i].Location = new System.Drawing.Point(25, 15);
                listOfNames[i].Name = "label" + (i + 1);
                listOfNames[i].Size = new System.Drawing.Size(69, 20);
                listOfNames[i].Text = "TEST";
            }
        }

        public void setUpPointLabels(int n)
        {
            listOfPoints = new List<Label>();

            int xValue = 0;
            float tSize = 14.25F;
            switch (n)
            {
                case 2: xValue = 290; tSize = 14.25F; break;
                case 3: xValue = 180; tSize = 12.25F; break;
                case 4: xValue = 118; tSize = 10.25F; break;
                default:
                    break;
            }

            for (int i = 0; i < n; i++)
            {
                listOfPoints.Add(new Label());

                listOfPoints[i].AutoSize = true;
                listOfPoints[i].BackColor = System.Drawing.Color.Transparent;
                listOfPoints[i].Font = new System.Drawing.Font("OCR A Extended", tSize, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                listOfPoints[i].ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(178)))), ((int)(((byte)(138)))));
                listOfPoints[i].Location = new System.Drawing.Point(xValue, 15);
                listOfPoints[i].Name = "label" + (i + 5);
                listOfPoints[i].Size = new System.Drawing.Size(45, 20);
                listOfPoints[i].Text = "test";
            }
        }
        #endregion

        #region Dice roll methods

        // returns 1 random int, in a range between 1-6
        public int getRandom()
        {
            Random randomInt = new Random();
            return randomInt.Next(1, 7);
        }

        // returns array of 6 int, in a range between 1-6
        public List<int> roll()
        {
            Random n = new Random();
            List<int> listOfDices = new List<int>();
            for (int i = 0; i < 6; i++)
            { listOfDices.Add(n.Next(1, 7)); }
            return listOfDices;
        }

        #endregion

        // quit button
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("Do you want to quit?","Warning", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            { Application.Exit(); }

        }

        
        // button3_Click event is responsible for game start
        int startIndex = 0;         // temporary variable which stores the index of a player who will start
        uint max = 0;               // temporary variable which stores, compares the rolled values of dices

        private void button3_Click(object sender, EventArgs e)
        {
            // delete the previously generated picturebox and clear array
            if (optionsCl.gameCounterInt > 0) { listOfPictureBoxes[0].Image = null; listOfPictureBoxes.Clear(); panel1.Controls.Clear(); }

            // throw one dice to determine who will start the entire game 
            if (optionsCl.gameCounterInt >= 0 && optionsCl.gameCounterInt <= optionsCl.numberOfPlayers)
            {
                // label5 shows which player rolled at the top of the playing field
                label5.Text = optionsCl.players[optionsCl.gameCounterInt].name;
                label5.Location = new Point(408 - label5.Size.Width / 2, label5.Location.Y);
                label5.ForeColor = optionsCl.players[optionsCl.gameCounterInt].color;

                // get random and update the label and player value
                optionsCl.players[optionsCl.gameCounterInt].point = (uint)getRandom();
                listOfPoints[optionsCl.gameCounterInt].Text = Convert.ToString(optionsCl.players[optionsCl.gameCounterInt].point);

                // set up picturebox
                createPictureBox(1);
                listOfPictureBoxes[0].Image = Image.FromFile(whichSetOfPics(Convert.ToInt32(optionsCl.players[optionsCl.gameCounterInt].point)));

                // here we compare the results and store the index number of a player who rolled the biggest value
                if (optionsCl.players[optionsCl.gameCounterInt].point > max)
                {
                    max = optionsCl.players[optionsCl.gameCounterInt].point;
                    startIndex = optionsCl.players.IndexOf(optionsCl.players[optionsCl.gameCounterInt]);
                }

                // increment the game counter
                optionsCl.gameCounterInt++;
            }

            // if all  players rolled the dice, the message box appears with info who will start the game. labels are cleared
            if (optionsCl.gameCounterInt >= optionsCl.players.Count)
            {
                MessageBox.Show($"{optionsCl.players[startIndex].name} you've rolled the highest number! You will get the first turn in the game. This means you will Start!");

                //this loop clears points of players
                for (int i = 0; i < optionsCl.players.Count; i++)
                { optionsCl.players[i].point = 0;
                  listOfPoints[i].Text = Convert.ToString(0); }

                // here we change the event from start, to main game process event, also clear the game panel from picture box.
                panel1.Controls.Clear();
                listOfPictureBoxes.Clear();
                button3.Click -= button3_Click;

                // here we put the index of the player who will start the game
                optionsCl.gameCounterInt = startIndex;

                // start timer
                date = DateTime.Now;
                timer = new Timer();
                timer.Interval = 10;
                timer.Tick += new EventHandler(tickTimer);
                timer.Start();

                // change event to the gameprocess event
                button3.Click += gameProcess;
            }
            button3.Enabled = false;
        }

        #region getting Image stuff

        // this method creates pictureboxes
        // if there 1 picturebox to create it will randomly choose a place 
        // in a limited area inside of panel1 to create a picturebox
        // if it is 6 than it X divides the area to six and places the boxes randomly on Y axis
        public void createPictureBox(int n)
        {
            listOfPictureBoxes = new List<PictureBox>();

            Random rand = new Random();

            for (int i = 0; i < n; i++)
            {
                int xVal = 0;
                listOfPictureBoxes.Add(new PictureBox());
                if (n==1)
                { xVal = rand.Next(66, 684); }
                else
                { xVal = 110 * i + 80; }
                listOfPictureBoxes[i].Location = new System.Drawing.Point(xVal, rand.Next(66,249));
                listOfPictureBoxes[i].Name = "pictureBox" + (i+1);
                listOfPictureBoxes[i].Size = new System.Drawing.Size(100, 100);
                listOfPictureBoxes[i].SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(listOfPictureBoxes[i]);
            }
        }

        public string whichSetOfPics(int n)
        {
            switch (optionsCl.diceType)
            {
                case 'R': return getThatImageRegular(n);
                case 'B': return getThatImageBlue(n);
                case 'M': return getThatImagePhi(n);
                default: return "";
            }
        }

        public string getThatImageRegular(int n)
        {
            switch (n)
            {

                case 1: return optionsCl.imageFolder + "diceregular\\Dice1static.png";
                case 2: return optionsCl.imageFolder + "diceregular\\Dice2static.png";
                case 3: return optionsCl.imageFolder + "diceregular\\Dice3static.png";
                case 4: return optionsCl.imageFolder + "diceregular\\Dice4static.png"; 
                case 5: return optionsCl.imageFolder + "diceregular\\Dice5static.png"; 
                case 6: return optionsCl.imageFolder + "diceregular\\Dice6static.png"; 
                default: return "";
                    
            }
        }

        public string getThatImageBlue(int n)
        {
            switch (n)
            {

                case 1: return optionsCl.imageFolder + "diceblue\\dice1.png";
                case 2: return optionsCl.imageFolder + "diceblue\\dice2.png";
                case 3: return optionsCl.imageFolder + "diceblue\\dice3.png";
                case 4: return optionsCl.imageFolder + "diceblue\\dice4.png";
                case 5: return optionsCl.imageFolder + "diceblue\\dice5.png";
                case 6: return optionsCl.imageFolder + "diceblue\\dice6.png";
                default: return "";

            }
        }

        public string getThatImagePhi(int n)
        {
            switch (n)
            {

                case 1: return optionsCl.imageFolder + "dicephi\\dice1.png";
                case 2: return optionsCl.imageFolder + "dicephi\\dice2.png";
                case 3: return optionsCl.imageFolder + "dicephi\\dice3.png";
                case 4: return optionsCl.imageFolder + "dicephi\\dice4.png";
                case 5: return optionsCl.imageFolder + "dicephi\\dice5.png";
                case 6: return optionsCl.imageFolder + "dicephi\\dice6.png";
                default: return "";

            }
        }

        public string getThatImageRed(int n)
        {
            switch (n)
            {

                case 1: return optionsCl.imageFolder + "dicered\\dice1.png";
                case 2: return optionsCl.imageFolder + "dicered\\dice2.png";
                case 3: return optionsCl.imageFolder + "dicered\\dice3.png";
                case 4: return optionsCl.imageFolder + "dicered\\dice4.png";
                case 5: return optionsCl.imageFolder + "dicered\\dice5.png";
                case 6: return optionsCl.imageFolder + "dicered\\dice6.png";
                default: return "";

            }
        }

        #endregion

        
        int counter;    // this counter counts ones, we need this to determine if the player loses his points
        public void gameProcess(object sender, EventArgs e)
        {
            // label5 demonstrates whose turn
            label5.Text = $"{optionsCl.players[optionsCl.gameCounterInt].name}'s turn!";
            label5.Location = new Point(408 - label5.Size.Width / 2, label5.Location.Y);
            label5.ForeColor = optionsCl.players[optionsCl.gameCounterInt].color;

            // clear array, panel from picutreboxes, but leave label which tells how much points did current player hit
            listOfPictureBoxes.Clear();
            panel1.Controls.Clear();
            panel1.Controls.Add(label6);

            // get that dices!!
            List<int> dices = roll();

            // create and put the proper images to pictureboxes
            createPictureBox(6);
            for (int j = 0; j < 6; j++)
            { listOfPictureBoxes[j].Image = Image.FromFile(whichSetOfPics(dices[j])); }

            // set counter of ONES to zero
            counter = 0;
            // this array stores indexes of ONES to change the picture to red to show the straight
            List<int> indexesOfZero = new List<int>();

            // this loop checkes the dices for ones, if they are found sets the point of current player to zero
            for (int j = 0; j < 6; j++)
            {
                if (dices[j] == 1) { counter++; }
                indexesOfZero.Add(j);

                if (counter >= 3)
                {
                    optionsCl.players[optionsCl.gameCounterInt].point = 0; listOfPoints[optionsCl.gameCounterInt].Text = "0";
                    for (int k = 0; k < 3; k++)
                    { listOfPictureBoxes[indexesOfZero[k]].Image = Image.FromFile(getThatImageRed(1)); }
                    label6.Text = $"{optionsCl.players[optionsCl.gameCounterInt].name} loses his points!";
                }
            }

            // if 3 ones are not found check for the remaining straights
            if (counter < 3)
            {
                if      (dices.Contains(1) && dices.Contains(2) && dices.Contains(3) && dices.Contains(4) && dices.Contains(5) && dices.Contains(6))
                {
                    optionsCl.players[optionsCl.gameCounterInt].point += 25; listOfPoints[optionsCl.gameCounterInt].Text = Convert.ToString(optionsCl.players[optionsCl.gameCounterInt].point);
                    for (int u = 1; u <= 6; u++)
                    { listOfPictureBoxes[dices.IndexOf(u)].Image = Image.FromFile(getThatImageRed(u)); }
                    label6.Text = $"25 points for {optionsCl.players[optionsCl.gameCounterInt].name}!";
                    // center the label
                    label6.Location = new Point(408 - label6.Size.Width / 2, label6.Location.Y);
                }
                else if (dices.Contains(1) && dices.Contains(2) && dices.Contains(3) && dices.Contains(4) && dices.Contains(5))
                {
                    optionsCl.players[optionsCl.gameCounterInt].point += 20; listOfPoints[optionsCl.gameCounterInt].Text = Convert.ToString(optionsCl.players[optionsCl.gameCounterInt].point);
                    for (int u = 1; u <= 5; u++)
                    { listOfPictureBoxes[dices.IndexOf(u)].Image = Image.FromFile(getThatImageRed(u)); }
                    label6.Text = $"20 points for {optionsCl.players[optionsCl.gameCounterInt].name}!";
                    label6.Location = new Point(408 - label6.Size.Width / 2, label6.Location.Y);
                }
                else if (dices.Contains(1) && dices.Contains(2) && dices.Contains(3) && dices.Contains(4))
                {
                    optionsCl.players[optionsCl.gameCounterInt].point += 15; listOfPoints[optionsCl.gameCounterInt].Text = Convert.ToString(optionsCl.players[optionsCl.gameCounterInt].point);
                    for (int u = 1; u <= 4; u++)
                    { listOfPictureBoxes[dices.IndexOf(u)].Image = Image.FromFile(getThatImageRed(u)); }
                    label6.Text = $"15 points for {optionsCl.players[optionsCl.gameCounterInt].name}!";
                    label6.Location = new Point(408 - label6.Size.Width / 2, label6.Location.Y);
                }
                else if (dices.Contains(1) && dices.Contains(2) && dices.Contains(3))
                {
                    optionsCl.players[optionsCl.gameCounterInt].point += 10; listOfPoints[optionsCl.gameCounterInt].Text = Convert.ToString(optionsCl.players[optionsCl.gameCounterInt].point);
                    for (int u = 1; u <= 3; u++)
                    { listOfPictureBoxes[dices.IndexOf(u)].Image = Image.FromFile(getThatImageRed(u)); }
                    label6.Text = $"10 points for {optionsCl.players[optionsCl.gameCounterInt].name}!";
                    label6.Location = new Point(408 - label6.Size.Width / 2, label6.Location.Y);
                }
                else if (dices.Contains(1) && dices.Contains(2))
                {
                    optionsCl.players[optionsCl.gameCounterInt].point += 5; listOfPoints[optionsCl.gameCounterInt].Text = Convert.ToString(optionsCl.players[optionsCl.gameCounterInt].point);
                    for (int u = 1; u <= 2; u++)
                    { listOfPictureBoxes[dices.IndexOf(u)].Image = Image.FromFile(getThatImageRed(u)); }
                    label6.Text = $"5 points for {optionsCl.players[optionsCl.gameCounterInt].name}!";
                    label6.Location = new Point(408 - label6.Size.Width / 2, label6.Location.Y);
                }
                else
                {
                    label6.Text = $"Maybe next roll {optionsCl.players[optionsCl.gameCounterInt].name} : (";
                    label6.Location = new Point(408 - label6.Size.Width / 2, label6.Location.Y);
                }
            }

            // if the current player collected the goal point, the game ends
            if (optionsCl.players[optionsCl.gameCounterInt].point >= optionsCl.goalPoint)
            {
                timer.Stop();
                label6.Text = $"Congrats {optionsCl.players[optionsCl.gameCounterInt].name}! : )";
                label6.Location = new Point(408 - label6.Size.Width / 2, label6.Location.Y);

                if (optionsCl.players[optionsCl.gameCounterInt].isBot)
                { MessageBox.Show($"Bot {optionsCl.players[optionsCl.gameCounterInt].name} wins.", "Finish!", MessageBoxButtons.OK); }
                else
                {
                    MessageBox.Show($"Congratulations {optionsCl.players[optionsCl.gameCounterInt].name}.\n" +
                        $"You have reached the goal point of {optionsCl.goalPoint} first!\n" +
                        $"It have taken you {label3.Text} to reach it!", "Finish!", MessageBoxButtons.OK);
                }

                button3.Enabled = false;
                button4.Enabled = false;
                button3.Enabled = false;
            }

            // disable the roll button and increment the game counter
            button3.Enabled = false;
            optionsCl.gameCounterInt++;
        }
        
        // next turn button
        private void button4_Click(object sender, EventArgs e)
        {
            button3.Enabled = true;

            // if game counter is bigger than the number of players set it to zero
            if (optionsCl.gameCounterInt >= optionsCl.players.Count)
            { optionsCl.gameCounterInt = 0; }

            // if the next player is bot, perform click on roll button
            if (optionsCl.players[optionsCl.gameCounterInt].isBot == true)
            { button3.PerformClick(); }
        }
     
        // timer stuff
        private void tickTimer(object sender, EventArgs e)
        {

            long tick = DateTime.Now.Ticks - date.Ticks;
            DateTime stopwatch = new DateTime();

            stopwatch = stopwatch.AddTicks(tick);
            label3.Text = string.Format("{0:mm:ss}", stopwatch);
        }

    }
}
