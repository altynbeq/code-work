﻿using System.Drawing;

namespace Project361
{
    public class Player
    {
        public uint point = 0;
        public Color color = new Color();
        public string name = "Player";
        public bool isBot = false;


        public Color SetColor
        {
            get { return color; }
            set { color = value; }
        }
    }
}
