﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project361
{
    public partial class gameSettings : Form
    {
        
        public gameSettings()
        {
            InitializeComponent();
        }

        // this arrays store labels, textboxes and buttons which are
        // generated on run-time to get players name and color
        List<Button> listOfButtons;
        List<TextBox> listOfTextBoxes;
        List<Label> listOfLabels;

        private void button4_Click(object sender, EventArgs e)
        {
            #region Data Validation Stuff
            Regex regex = new Regex("^[1-4]");
            bool isOnlyNum = regex.IsMatch(numberOfPlayers.Text);
            regex = new Regex("^[0-4]");
            bool isOnlyNumBot = regex.IsMatch(numberOfBots.Text);
            bool isDigitOnly(string str)
            {
                foreach (char c in str)
                { if (c < '0' || c > '9') return false; }
                return true;
            }
            #endregion

            if (!isOnlyNum) // check number of players textbox for valid input
            { MessageBox.Show("Error: Number of players can contain only numbers in a range from 1 -> 4.", "Error"); }
            else if (!isOnlyNumBot) // check number of bots textbox for valid input
            { MessageBox.Show("Error: Number of bots can contain only numbers in a range from 0 -> 4.", "Error"); }
            else if (!isDigitOnly(goalPoint.Text)) // check goal point textbox for valid input
            { MessageBox.Show("Error: Goal point can contain only numbers.", "Error"); }
            else if (!(Convert.ToInt32(goalPoint.Text) >= 1) || !(Convert.ToInt32(goalPoint.Text) <= 1000)) // check goal point textbox for valid input
            { MessageBox.Show("Error: Goal point can contain only numbers in a range from 1 -> 1000", "Error"); }
            else
            {
                optionsCl.numberOfPersons = Convert.ToInt32(numberOfPlayers.Text);
                optionsCl.goalPoint = Convert.ToInt32(goalPoint.Text);
                optionsCl.numberOfBots = Convert.ToInt32(numberOfBots.Text);

                // check if total number of players is not bigger than 4 and not less than 2
                if (optionsCl.numberOfBots + optionsCl.numberOfPersons < 2 || optionsCl.numberOfBots + optionsCl.numberOfPersons > 4)
                { MessageBox.Show("Error: The total number of players should be maximum 4.\nIncluding bots in sum.", "Error"); }
                else
                {
                    // clear everything in the form except main label and the button
                    Controls.Clear();
                    Controls.Add(label1);
                    Controls.Add(button4);

                    // set up input prompts for each player, based on the number of players
                    setUpLabels(optionsCl.numberOfPersons);
                    setUpTextBoxes(optionsCl.numberOfPersons);
                    setUpButtons(optionsCl.numberOfPersons);

                    // change event so we can open main playing field
                    button4.Click -= button4_Click;
                    button4.Click += startOpenMainPanel;
                }
            }
        }

        // this event gets the data about players from prompts which were generated in button4_Click event
        private void startOpenMainPanel(object sender, EventArgs e)
        {
            // reset the array of players
            optionsCl.players.Clear();

            optionsCl.numberOfPlayers = optionsCl.numberOfPersons + optionsCl.numberOfBots;
            Random rand = new Random();
            int ranNum;

            // get all info from textboxes and buttons to the array of players
            for (int i = 0; i < optionsCl.numberOfPersons; i++)
            {
                optionsCl.players.Add(new Player());
                optionsCl.players[i].name = listOfTextBoxes[i].Text;
                optionsCl.players[i].SetColor = listOfButtons[i].BackColor;
            }

            // randomly fill the array of players with info about bots
            for (int i = optionsCl.players.Count; i < optionsCl.numberOfPlayers; i++)
            {
                ranNum = rand.Next(1, 7);
                optionsCl.players.Add(new Player());
                optionsCl.players[i].name = getBotName(ranNum);
                ranNum = rand.Next(1, 7);
                optionsCl.players[i].SetColor = getBotColors(ranNum);
                optionsCl.players[i].isBot = true;
            }

            // open main playing field
            playingField playingField = new playingField();
            playingField.Show();
            this.Close();
        }

        // here everything is clear i think
        #region Set Up Prompt for each Player

        private void setUpLabels(int n)
        {
            listOfLabels = new List<Label>();

            for (int i = 0; i < n; i++)
            {
                listOfLabels.Add(new Label());

                listOfLabels[i].Name = "label" + Convert.ToString(i + 1);
                listOfLabels[i].BackColor = System.Drawing.Color.Transparent;
                listOfLabels[i].Font = new System.Drawing.Font("OCR A Extended", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                listOfLabels[i].ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(178)))), ((int)(((byte)(138)))));
                listOfLabels[i].Location = new System.Drawing.Point(27, (i * 78) + 109);
                listOfLabels[i].Size = new System.Drawing.Size(71, 13);
                listOfLabels[i].Text = $"Player {i + 1}";
                Controls.Add(listOfLabels[i]);
            }
        }
        private void setUpTextBoxes(int n)
        {
            listOfTextBoxes = new List<TextBox>();

            for (int i = 0; i < n; i++)
            {
                listOfTextBoxes.Add(new TextBox());

                listOfTextBoxes[i].BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(51)))), ((int)(((byte)(64)))));
                listOfTextBoxes[i].BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                listOfTextBoxes[i].Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                listOfTextBoxes[i].ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(178)))), ((int)(((byte)(138)))));
                listOfTextBoxes[i].Name = "textBox" + Convert.ToString(i + 1);
                listOfTextBoxes[i].Location = new Point(30, (i * 78) + 127);
                listOfTextBoxes[i].Size = new Size(253, 35);
                listOfTextBoxes[i].TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
                Controls.Add(listOfTextBoxes[i]);
            }
        }
        private void setUpButtons(int n)
        {
            listOfButtons = new List<Button>();

            for (int i = 0; i < n; i++)
            {
                listOfButtons.Add(new Button());

                listOfButtons[i].Name = "button" + Convert.ToString(i + 1);
                listOfButtons[i].FlatStyle = System.Windows.Forms.FlatStyle.Popup;
                listOfButtons[i].Text = "";
                listOfButtons[i].BackColor = Color.Blue;
                listOfButtons[i].Location = new Point(298, (i * 78) + 127);
                listOfButtons[i].Size = new Size(35, 35);
                listOfButtons[i].UseVisualStyleBackColor = false;
                listOfButtons[i].Click += setColor;
                this.Controls.Add(listOfButtons[i]);

            }
        }

        #endregion

        // this event is needed to get color from buttons which were generated on run-time
        private void setColor(object s, EventArgs e)
        {
            Button b = (Button)s;
            colorDialog1.ShowDialog();
            b.BackColor = colorDialog1.Color;
        }

        #region Bot Value Stuff
        // these two methods store the list of names and colors which could be assigned to bots
        public string getBotName(int n)
        {
            switch (n)
            {
                case 1: return "Drake";
                case 2: return "John";
                case 3: return "Derek";
                case 4: return "Donald";
                case 5: return "Elon";
                case 6: return "Alex";
                default: return "Player";
            }
        }
        public Color getBotColors(int n)
        {
            switch (n)
            {
                case 1: return Color.Red;
                case 2: return Color.Blue;
                case 3: return Color.Yellow;
                case 4: return Color.Black;
                case 5: return Color.Green;
                case 6: return Color.DeepPink;
                default: return Color.Transparent;
            }
        }
        #endregion

        // these events select all when you click on textbox
        private void numberOfPlayers_MouseClick(object sender, MouseEventArgs e)
        { numberOfPlayers.SelectAll(); }
        private void numberOfBots_MouseClick(object sender, MouseEventArgs e)
        { numberOfBots.SelectAll(); }
        private void goalPoint_MouseClick(object sender, MouseEventArgs e)
        { goalPoint.SelectAll(); }
    }
}
