// counting valleys

let arr = ['UUU'];


for (let i = 0; i < arr.length; i++) {
    let sec = 0;
    if (arr[i] === 'U') {
        sec = sec + 1;
    } else if (arr[i] == 'D') {
        sec = sec - 1;
    }
}