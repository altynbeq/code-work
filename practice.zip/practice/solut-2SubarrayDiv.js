let numbers = [1, 2, 3, 4, 5, 6];
let k = 5;
let count = 0;
for (let i = 0; i < numbers.length; i++) {
    for (let j = 0; j < numbers.length; j++) {
        if (numbers[i] < numbers[j] && (numbers[i] + numbers[j]) % k == 0) {
            count++;
        }
    }
}
console.log(count);