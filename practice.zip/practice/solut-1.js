const scores = [3, 4, 21, 36, 10, 28, 35, 5, 24, 42];
let minScore = scores[0];
let maxScore = scores[0];
let minRecord = 0;
let maxRecord = 0;

for (let i = 0; i < scores.length; i++) {
    if (minScore < scores[i]) {
        minScore = scores[i];
        minRecord++;
    }
    if (maxScore > scores[i]) {
        maxScore = scores[i];
        maxRecord++;
    }
}
console.log(minRecord + ' ' + maxRecord);