//bill division 
let bill = [3, 10, 2, 9];
let noEat = 1;
let charged = 12;


let total = bill.reduce(function(a, b) {
    return a + b;
}, 0);

if (b == (total - bill[k]) / 2) {
    console.log('u got it')
} else {
    console.log(b - ((total - bill[k]) / 2))
}