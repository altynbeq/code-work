import React from "react";
import ReactDOM from "react-dom";
import App from "./Container/AppFunction";

ReactDOM.render( <
    App / > ,
    document.getElementById("app")
);