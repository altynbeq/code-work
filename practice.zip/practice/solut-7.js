//Drawing books

let n = 6;
let p = 2;

let mid = n / 2;

if (p % 2 == 0) {
    console.log('here')
} else if (p % 2 == 1) {
    console.log('odd')
}

if (p > mid) {
    console.log((n - p) / 2)
} else if (p < mid) {
    console.log(p / 2);
}