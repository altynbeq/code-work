// sales by match 

let ar = [10, 20, 20, 10, 10, 30, 50, 10, 20];

for (let i = 0; i < ar.length; i++) {
    for (let j = 0; j < ar.length; j++) {
        if (ar[i] == ar[j]) {
            console.log(ar[i], ar[j])
        }
    }
}

function checker() {
    if (ar[i] == ar[j]) {

    }
}